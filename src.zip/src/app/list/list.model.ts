export class StudentModel{
    id : number = 0;
    FirstName : string = '';
    LastName : string = '';
    DOB   : string = '';
    Gender : string = '';
    Hobbies : string = '';
}