import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup} from '@angular/forms';
import { ApiService } from '../server/api.service';
import { StudentModel } from './list.model';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  formValue !: FormGroup;
  StudentModelobj : StudentModel = new StudentModel();
  StudentsData ! :any;
  showAdd !:boolean;
  showUpdate !:boolean;


  constructor(private formbuilder : FormBuilder, private api : ApiService)    //Here Is the Problem other than nice this api service will not showing sometimes result Thank you for the Oppurtnity//
   { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      FirstName : [''],
      LastName  :[''],
      DOB       :[''],
      Gender    :[''],
      Hobbies   :[''],
    })
    this.getAllStudents();
  }
   clickaddStudent(){
     this.formValue.reset();
     this.showAdd = true;
     this.showUpdate = false;
   }
  postStudentDetails(){
    this.StudentModelobj.FirstName = this.formValue.value.FirstName;
    this.StudentModelobj.LastName = this.formValue.value.LastName;
    this.StudentModelobj.DOB = this.formValue.value.DOB;
    this.StudentModelobj.Gender = this.formValue.value.Gender;
    this.StudentModelobj.Hobbies = this.formValue.value.Hobbies;


    this.api.this.postStudent(this.StudentModelobj)
    .subscribe((res: any)=>{
      console.log(res);
      alert("Student Added Successfully")
      let ref = document.getElementById('cancel')
      ref?.click()
      this.formValue.reset();
      this.getAllStudents();
    },
      (err:any)=>{
      alert("something went wrong")
    })
  }

  getAllStudents(){
    this.api.getStudent()
    .subscribe((res: any)=>{
      this.StudentsData=res;

      
    })
  }

  deleteStudent(row : any){
    this.api.deleteStudent(row.id)
    .subscribe((res: any)=>{
      alert("Student Deleted");
      this.getAllStudents();
    })
   }

   onEdit(row : any){
    this.showAdd = false;
    this.showUpdate = true;
     this.StudentModelobj.id=row.id;
     this.formValue.controls['FirstName'].setValue(row.FirstName);
     this.formValue.controls['LastName'].setValue(row.LastName);
     this.formValue.controls['DOB'].setValue(row.DOB);
     this.formValue.controls['Gender'].setValue(row.Gender);
     this.formValue.controls['Hobbies'].setValue(row.Hobbies);

   }
   updateStudentDetails(){
    this.StudentModelobj.FirstName = this.formValue.value.FirstName;
    this.StudentModelobj.LastName = this.formValue.value.LastName;
    this.StudentModelobj.DOB = this.formValue.value.DOB;
    this.StudentModelobj.Gender = this.formValue.value.Gender;
    this.StudentModelobj.Hobbies = this.formValue.value.Hobbies;
    this.api.updateStudent(this.StudentModelobj,this.StudentModelobj.id)
    .subscribe((res: any)=>{
      alert("updated successfully")
      let ref = document.getElementById('cancel')
      ref?.click()
      this.formValue.reset();
      this.getAllStudents();
    })

   }


}









